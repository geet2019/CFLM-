
import numpy as np
import tensorflow as tf
from dataio import *
from generator import *

# Q8 accuracy calculation
def calculate_Q8accuracy(PRED, YTRUE):
    result = 0
    l = len(PRED)
    for c1, c2 in zip(PRED, YTRUE):
        if c1 != c2:
            m += 1
    q = (m/l) 
    a = float(q*100)
    acc = round(a,2)
    print("Q8 accuracy of query protein sequence :%.2f" %acc)
       
# Q3 accuracy calculation
def calculate_Q3accuracy(PRED, YTRUE):
    result = 0
    l = len(PRED)
    for c1, c2 in zip(PRED, YTRUE):
        if c1 != c2:
            m += 1
    q = (m/l) 
    a = float(q*100)
    acc = round(a,2)
    print("Q3 accuracy of query protein sequence :%.2f" %acc)
   
# convert eight to three     
def eight_to_three(sec_structure):
    sec_structure = sec_structure.replace('-', 'C')
    sec_structure = sec_structure.replace('I', 'C')
    sec_structure = sec_structure.replace('T', 'C')
    sec_structure = sec_structure.replace('S', 'C')
    sec_structure = sec_structure.replace('G', 'H')
    sec_structure = sec_structure.replace('B', 'E')
    print("Predicted Secondary structure (Q3): %s" %sec_structure) 
    
# secondary prediction     
def secondary_struct_predictions(my_model, my_list, my_length_dict,pad_size,flag_save, LMAX):
    # Padded but full inputs/outputs
    my_generator = SecondaryGenerator(sequence)
    P = my_model.predict_generator(my_generator)
    print("Predicted Secondary structure (Q8): %s" %P)
    calculate_Q8accuracy(PRED, YTRUE)

    eight_to_three(sec_structure)

    calculate_Q3accuracy(PRED, YTRUE)

    if flag_save:
        os.system('mkdir -p ./predictions')
        for i in range(len(my_list)):
            L = my_length_dict[my_list[i]]
            pred = P[i, :L, :L]
            save_secondary_rr('.4bydist.rr')


