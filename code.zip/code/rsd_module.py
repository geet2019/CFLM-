import pandas as pd
import tensorflow as tf
from tensorflow.keras.layers import Conv2D
from tensorflow.keras import Model
from tensorflow.keras.initializers import he_normal
from tensorflow.python.keras.layers import Input, Convolution2D, Activation, MaxPooling2D

class sec_struct(Conv2D):

    def __init__(self ):
        pass
           
    def call(self, inputs):
        return self._phase_shift(super(sec_struct, self).call(inputs))

    def compute_output_shape(self, input_shape):
        unshifted = super(sec_struct, self).compute_output_shape(input_shape)
        return (unshifted[0], self.r*unshifted[1], self.r*unshifted[2], int(unshifted[3]/(self.r*self.r)))

class ResidualDenseBlock(Model):
    def __init__(self, num_G):
        super(ResidualDenseBlock, self).__init__()
        self.num_G = num_G
        self.c1 = Conv2D(filters=num_G, kernel_initializer=he_normal(), kernel_size=(3, 3), activation='relu',padding='same')
        self.c2 = Conv2D(filters=num_G, kernel_initializer=he_normal(), kernel_size=(3, 3), activation='relu',padding='same')
        self.c3 = Conv2D(filters=num_G, kernel_initializer=he_normal(), kernel_size=(3, 3), activation='relu',padding='same')
        self.c4 = Conv2D(filters=num_G, kernel_initializer=he_normal(), kernel_size=(3, 3), activation='relu',padding='same')
        self.c5 = Conv2D(filters=num_G, kernel_initializer=he_normal(), kernel_size=(3, 3), activation='relu',padding='same')
        self.c6 = Conv2D(filters=num_G, kernel_initializer=he_normal(), kernel_size=(3, 3), activation='relu',padding='same')
        self.c = Conv2D(filters=64, kernel_initializer=he_normal(), kernel_size=(1, 1), padding='same')

    def call(self, inputs):
        x1 = self.c1(inputs)
        y1 = tf.concat([inputs, x1], 3)
        x2 = self.c2(y1)
        y2 = tf.concat([inputs, x1, x2], 3)
        x3 = self.c3(y2)
        y3 = tf.concat([inputs, x1, x2, x3], 3)
        x4 = self.c4(y3)
        y4 = tf.concat([inputs, x1, x2, x3, x4], 3)
        x5 = self.c5(y4)
        y5 = tf.concat([inputs, x1, x2, x3, x4, x5], 3)
        x6 = self.c6(y5)
        y6 = tf.concat([inputs, x1, x2, x3, x4, x5, x6], 3)
        y = self.c(y6)
        return y + inputs

class RDN(Model):
    def __init__(self, num_G, channels, scale):
        super(RDN, self).__init__()
        self.num_G = num_G
        self.channels = channels
        self.scale = scale
        
        self.RDB1 = ResidualDenseBlock(self.num_G)
        self.RDB2 = ResidualDenseBlock(self.num_G)
        self.RDB3 = ResidualDenseBlock(self.num_G)
        self.RDB4 = ResidualDenseBlock(self.num_G)
        self.RDB5 = ResidualDenseBlock(self.num_G)
        self.RDB6 = ResidualDenseBlock(self.num_G)
        self.RDB7 = ResidualDenseBlock(self.num_G)
        self.RDB8 = ResidualDenseBlock(self.num_G)
        self.RDB9 = ResidualDenseBlock(self.num_G)
        self.RDB10 = ResidualDenseBlock(self.num_G)
        self.RDB11 = ResidualDenseBlock(self.num_G)
        self.RDB12 = ResidualDenseBlock(self.num_G)
        self.RDB13 = ResidualDenseBlock(self.num_G)
        self.RDB14 = ResidualDenseBlock(self.num_G)
        self.RDB15 = ResidualDenseBlock(self.num_G)
        self.RDB16 = ResidualDenseBlock(self.num_G)
        self.RDB17 = ResidualDenseBlock(self.num_G)
        self.RDB18 = ResidualDenseBlock(self.num_G)
        self.RDB19 = ResidualDenseBlock(self.num_G)
        self.RDB20 = ResidualDenseBlock(self.num_G)

        self.GFF1 = Conv2D(filters=64, kernel_initializer=he_normal(), kernel_size=(1, 1), padding='same')
        self.GFF2 = Conv2D(filters=64, kernel_initializer=he_normal(), kernel_size=(3, 3), padding='same')

        self.UP = sec_struct(64, (3,3), r=scale, padding='same',activation='relu')

        self.c = Conv2D(filters=self.channels, kernel_initializer=he_normal(), kernel_size=(3, 3), padding='same')

    def call(self, inputs):
        sfe1 = self.SFE1(inputs)
        sfe2 = self.SFE2(sfe1)

        rdb1 = self.RDB1(sfe2)
        rdb2 = self.RDB2(rdb1)
        rdb3 = self.RDB3(rdb2)
        rdb4 = self.RDB4(rdb3)
        rdb5 = self.RDB5(rdb4)
        rdb6 = self.RDB6(rdb5)
        rdb7 = self.RDB7(rdb6)
        rdb8 = self.RDB8(rdb7)
        rdb9 = self.RDB9(rdb8)
        rdb10 = self.RDB10(rdb9)
        rdb11 = self.RDB11(rdb10)
        rdb12 = self.RDB12(rdb11)
        rdb13 = self.RDB13(rdb12)
        rdb14 = self.RDB14(rdb13)
        rdb15 = self.RDB15(rdb14)
        rdb16 = self.RDB16(rdb15)
        rdb17 = self.RDB17(rdb16)
        rdb18 = self.RDB18(rdb17)
        rdb19 = self.RDB19(rdb18)
        rdb20 = self.RDB20(rdb19)
        rdb = tf.concat([rdb1, rdb2, rdb3, rdb4, rdb5, rdb6, rdb7, rdb8, rdb9, rdb10,
                rdb11, rdb12, rdb13, rdb14, rdb15, rdb16, rdb17, rdb18, rdb19, rdb20], 3)

        gff1 = self.GFF1(rdb)
        gff2 = self.GFF2(gff1)
        dff = sfe1 + gff2
        up = self.UP(dff)

# Architecture (Direct training)
def secondary_struct_eight_arch(L, num_blocks, width, expected_n_channels):
    bins = 3
    my_input = Input(shape = (700,54))
    tower = Activation('relu')(my_input)
    tower = Convolution2D(width, 1, padding = 'same')(tower)
    tower = MaxPooling2D(pool_size = 2, strides = 2)
    tower = RDN(num_blocks)(tower)
    tower = Activation('relu')(tower)
    tower = Convolution2D(bins, 8, padding = 'same')(tower)
    tower = Activation('softmax')(tower)
    model = Model(my_input, tower)
    return model

# First stage transfer learning 
def secondary_struct_eight_arch3(L, num_blocks, width, expected_n_channels):
    bins = 3
    my_input = Input(shape = (700, 52, expected_n_channels))
    tower = secondary_struct_eight_arch(L, num_blocks, width, expected_n_channels)
    for layers in tower.layers[:11]:
      layers.trainable = False 
    for layers in tower.layers[11:]:
      layers.trainable = True 
    tower = RDN(num_blocks)(tower)
    tower = Activation('relu')(tower)
    tower = Convolution2D(bins, 8, padding = 'same')(tower)
    tower = Activation('softmax')(tower)
    model = Model(my_input, tower)
    return model
# Second stage transfer learning 

def secondary_struct_eight_arch2(L, num_blocks, width, expected_n_channels):
    bins = 3
    my_input = Input(shape = (700, 52, expected_n_channels))
    tower = secondary_struct_eight_arch3(L, num_blocks, width, expected_n_channels)
    for layers in tower.layers[:15]:
      layers.trainable = True 
    for layers in tower.layers[15:]:
      layers.trainable = False 
    tower = RDN(num_blocks)(tower)
    tower = Activation('relu')(tower)
    tower = Convolution2D(bins, 8, padding = 'same')(tower)
    tower = Activation('softmax')(tower)
    model = Model(my_input, tower)
    return model

sqtype = int(input("Enter the dataset type: Type 1 or 2 or 3 :   "))
df = pd.read_excel('D:/GEETHU S/My_Project/My_Project/Feature_extraction/SF.xlsx')

print("check 1")
if sqtype == 1:
    model = secondary_struct_eight_arch(df.shape[0],20,df.shape[1],df)
    print("Training started using Direct training")
elif sqtype == 3:
    model = secondary_struct_eight_arch3(df.shape[0],20,df.shape[1],df)
    print("Training started using First stage transfer learning ")
elif sqtype == 3:
    model = secondary_struct_eight_arch2(df.shape[0],20,df.shape[1],df)
    print("Training started using Second stage transfer learning ")
model.compile(loss = 'categorical_crossentropy', optimizer = 'adam', metrics = ['accuracy'])   

df = pd.read_excel('D:/GEETHU S/My_Project/My_Project/Feature_extraction/SF.xlsx')

X_train = df.iloc[1::,1:55]
Y_train = df.iloc[1::,56]

losses = model.fit(X_train, Y_train, batch_size=256, epochs=15)