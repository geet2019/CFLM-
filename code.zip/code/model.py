
import tensorflow as tf
from tensorflow.python.keras import layers

from tensorflow.python.keras.layers import Input, Convolution2D, Activation, add, Dropout, BatchNormalization
from tensorflow.python.keras.models import Model


class sec_struct(Conv2D):

    def __init__(self,
               features,
               max_range,
               min_range,
               position_specific_bias_size=0,
               is_ca_feature=False,
               name='sec_struct'):
        super(sec_struct, self).__init__(name=name)        
        
        self._is_ca_feature = is_ca_feature
        self._features = features
        self._max_range = max_range
        self._min_range = min_range
        self._position_specific_bias_size = position_specific_bias_size
           
    def call(self, inputs):
        return self._phase_shift(super(sec_struct, self).call(inputs))

    def compute_output_shape(self, input_shape):
        unshifted = super(sec_struct, self).compute_output_shape(input_shape)
        return (unshifted[0], self.r*unshifted[1], self.r*unshifted[2], int(unshifted[3]/(self.r*self.r)))

class ResidualDenseBlock(Model):
    def __init__(self, num_G):
        super(ResidualDenseBlock, self).__init__()
        self.num_G = num_G

        self.c1 = Conv2D(filters=num_G, kernel_initializer=he_normal(), kernel_size=(3, 3), activation='relu',
                         padding='same')
        self.c2 = Conv2D(filters=num_G, kernel_initializer=he_normal(), kernel_size=(3, 3), activation='relu',
                         padding='same')
        self.c3 = Conv2D(filters=num_G, kernel_initializer=he_normal(), kernel_size=(3, 3), activation='relu',
                         padding='same')
        self.c4 = Conv2D(filters=num_G, kernel_initializer=he_normal(), kernel_size=(3, 3), activation='relu',
                         padding='same')
        self.c5 = Conv2D(filters=num_G, kernel_initializer=he_normal(), kernel_size=(3, 3), activation='relu',
                         padding='same')
        self.c6 = Conv2D(filters=num_G, kernel_initializer=he_normal(), kernel_size=(3, 3), activation='relu',
                         padding='same')

        self.c = Conv2D(filters=64, kernel_initializer=he_normal(), kernel_size=(1, 1), padding='same')

    def call(self, inputs):
        x1 = self.c1(inputs)
        y1 = tf.concat([inputs, x1], 3)

        x2 = self.c2(y1)
        y2 = tf.concat([inputs, x1, x2], 3)

        x3 = self.c3(y2)
        y3 = tf.concat([inputs, x1, x2, x3], 3)

        x4 = self.c4(y3)
        y4 = tf.concat([inputs, x1, x2, x3, x4], 3)

        x5 = self.c5(y4)
        y5 = tf.concat([inputs, x1, x2, x3, x4, x5], 3)

        x6 = self.c6(y5)
        y6 = tf.concat([inputs, x1, x2, x3, x4, x5, x6], 3)

        y = self.c(y6)
        return y + inputs


class RDN(Model):
    def __init__(self, num_G, channels, scale):
        super(RDN, self).__init__()
        self.num_G = num_G
        self.channels = channels
        self.scale = scale
        
        self.RDB1 = ResidualDenseBlock(self.num_G)
        self.RDB2 = ResidualDenseBlock(self.num_G)
        self.RDB3 = ResidualDenseBlock(self.num_G)
        self.RDB4 = ResidualDenseBlock(self.num_G)
        self.RDB5 = ResidualDenseBlock(self.num_G)
        self.RDB6 = ResidualDenseBlock(self.num_G)
        self.RDB7 = ResidualDenseBlock(self.num_G)
        self.RDB8 = ResidualDenseBlock(self.num_G)
        self.RDB9 = ResidualDenseBlock(self.num_G)
        self.RDB10 = ResidualDenseBlock(self.num_G)
        self.RDB11 = ResidualDenseBlock(self.num_G)
        self.RDB12 = ResidualDenseBlock(self.num_G)
        self.RDB13 = ResidualDenseBlock(self.num_G)
        self.RDB14 = ResidualDenseBlock(self.num_G)
        self.RDB15 = ResidualDenseBlock(self.num_G)
        self.RDB16 = ResidualDenseBlock(self.num_G)
        self.RDB17 = ResidualDenseBlock(self.num_G)
        self.RDB18 = ResidualDenseBlock(self.num_G)
        self.RDB19 = ResidualDenseBlock(self.num_G)
        self.RDB20 = ResidualDenseBlock(self.num_G)

        self.GFF1 = Conv2D(filters=64, kernel_initializer=he_normal(), kernel_size=(1, 1), padding='same')
        self.GFF2 = Conv2D(filters=64, kernel_initializer=he_normal(), kernel_size=(3, 3), padding='same')

        self.UP = sec_struct(64, (3,3), r=scale, padding='same',activation='relu')

        self.c = Conv2D(filters=self.channels, kernel_initializer=he_normal(), kernel_size=(3, 3), padding='same')

    def call(self, inputs):
        sfe1 = self.SFE1(inputs)
        sfe2 = self.SFE2(sfe1)

        rdb1 = self.RDB1(sfe2)
        rdb2 = self.RDB2(rdb1)
        rdb3 = self.RDB3(rdb2)
        rdb4 = self.RDB4(rdb3)
        rdb5 = self.RDB5(rdb4)
        rdb6 = self.RDB6(rdb5)
        rdb7 = self.RDB7(rdb6)
        rdb8 = self.RDB8(rdb7)
        rdb9 = self.RDB9(rdb8)
        rdb10 = self.RDB10(rdb9)
        rdb11 = self.RDB11(rdb10)
        rdb12 = self.RDB12(rdb11)
        rdb13 = self.RDB13(rdb12)
        rdb14 = self.RDB14(rdb13)
        rdb15 = self.RDB15(rdb14)
        rdb16 = self.RDB16(rdb15)
        rdb17 = self.RDB17(rdb16)
        rdb18 = self.RDB18(rdb17)
        rdb19 = self.RDB19(rdb18)
        rdb20 = self.RDB20(rdb19)
        rdb = tf.concat([rdb1, rdb2, rdb3, rdb4, rdb5, rdb6, rdb7, rdb8, rdb9, rdb10,
                rdb11, rdb12, rdb13, rdb14, rdb15, rdb16, rdb17, rdb18, rdb19, rdb20], 3)

        gff1 = self.GFF1(rdb)
        gff2 = self.GFF2(gff1)
        dff = sfe1 + gff2

        up = self.UP(dff)


# Direct-training 
def direct_training(L, num_blocks, width, expected_n_channels):
    input_shape = (L, L, expected_n_channels)
    img_input = layers.Input(shape = input_shape)
    RDB(img_input)
    rdb1.trainable=False
    rdb2.trainable=False
    rdb3.trainable=False
    rdb4.trainable=False
    rdb5.trainable=False
    rdb6.trainable=False
    rdb7.trainable=False
    rdb8.trainable=False
    rdb9.trainable=False
    rdb10.trainable=False
    rdb11.trainable=False
    return model
    
    
# First_level transfer learning  
def first_level(L, num_blocks, width, expected_n_channels):
    input_shape = (L, L, expected_n_channels)
    img_input = layers.Input(shape = input_shape)
    RDB(img_input)
    rdb1.trainable=False
    rdb2.trainable=False
    rdb3.trainable=False
    rdb4.trainable=False
    rdb5.trainable=False
    rdb6.trainable=False
    rdb7.trainable=False
    rdb8.trainable=False
    rdb9.trainable=False
    rdb10.trainable=False
    rdb11.trainable=False
    return model

# Second_level transfer learning 
def second_level(L, num_blocks, width, expected_n_channels):
    input_shape = (L, L, expected_n_channels)
    img_input = layers.Input(shape = input_shape)
    RDB(img_input)
    rdb1.trainable=False
    rdb2.trainable=False
    rdb3.trainable=False
    rdb4.trainable=False
    rdb5.trainable=False
    rdb6.trainable=False
    rdb7.trainable=False
    rdb8.trainable=False
    rdb9.trainable=False
    rdb10.trainable=False
    rdb11.trainable=False
    rdb12.trainable=False
    rdb13.trainable=False
    rdb14.trainable=False
    rdb15.trainable=False
    return model


