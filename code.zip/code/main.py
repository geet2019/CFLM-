import tensorflow as tf
from tensorflow.keras.callbacks import ModelCheckpoint
import os
import sys
import numpy as np
import datetime
import argparse
sys.path.insert(0, os.path.dirname(os.path.abspath(sys.argv[0])) + '/lib')
from dataio import *
from metrics import *
from generator import *
from models import *
from losses import *

test_data = np.load('t0949-d1.aln') 

main.pgmain3()

# Parameters for "example" run
L           = 128
chain       = 20 
count      = 128
channels    = 54


dataset1 = load_list(dir_dataset + 'dataset1.npy.gz')

length_dict = {}
for pdb in dataset1:
    length_dict[pdb] = np.load('dataset1.npy.gz', allow_pickle = True)
train_set = train_data1[:11879]
train_generator = SecondaryGenerator(train_set)
model = ''
model = direct_training(L, chain, count, channels)
model.compile(loss = 'categorical_crossentropy', optimizer = 'rmsprop', metrics = ['accuracy'])
model.fit(generator = train_generator,validation_data = valid_generator,verbose = 1,max_queue_size = 8,workers = 1,use_multiprocessing = False,shuffle = True ,epochs = 8)



dataset2 = load_list(dir_dataset + 'dataset2.npy.gz')

length_dict = {}
for pdb in dataset1:
    length_dict[pdb]= np.load('dataset2.npy.gz', allow_pickle = True)
     
train_set2 = train_data2[:6729]
train_generator = SecondaryGenerator(train_set1)
model = first_level(L, chain, count, channels)
model.compile(loss = 'categorical_crossentropy', optimizer = 'rmsprop', metrics = ['accuracy'])
model.fit(generator = train_generator,validation_data = valid_generator,verbose = 1,max_queue_size = 8,workers = 1,use_multiprocessing = False,shuffle = True ,epochs = 5)


dataset3 = load_list(dir_dataset + 'dataset3.npy.gz')

length_dict = {}
for pdb in dataset1:
    length_dict[pdb]= np.load('dataset3.npy.gz', allow_pickle = True)
   
train_set2 = train_data2[:621]
train_generator = SecondaryGenerator(train_set2)
model = second_level(L, chain, count, channels)
model.compile(loss = 'categorical_crossentropy', optimizer = 'rmsprop', metrics = ['accuracy'])    
model.fit(generator = train_generator,validation_data = valid_generator,verbose = 1,max_queue_size = 8,workers = 1,use_multiprocessing = False,shuffle = True ,epochs = 3)

# Testing

test = load_list('T0949-d1')

model.load_weights(file_weights)
eval_secondary_predictions(model, test)


